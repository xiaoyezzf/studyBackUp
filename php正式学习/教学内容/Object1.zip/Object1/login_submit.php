<?php
	require('db.php');
	if(!empty($_POST)) {
		$uname = $_POST['uname'];
		$pwd = md5($_POST['pwd']);
		$sql = "SELECT * FROM user WHERE uname='{$uname}'";
		$res = DB($sql);
		var_dump($res);
		if (count($res) > 0 && $pwd == $res[0]['pwd']) {
			echo "成功";
			header("Refresh:3,url=home.php");
		} else {
			echo "失败";
			header("Refresh:3,url=login.html");
		}
	}
?>