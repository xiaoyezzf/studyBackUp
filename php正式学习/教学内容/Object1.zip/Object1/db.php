<?php
	
	function DB($sql,$dbname='object',$type = MYSQLI_ASSOC) {
		$link = mysqli_connect('localhost','root','',$dbname);
		$res = mysqli_query($link,$sql);
		$sql = strtoupper($sql);
		if (substr_count($sql, "SELECT")) {
			$rows= array();
			while ($row = mysqli_fetch_array($res,$type)) {
				$rows[] = $row;
			}
			return $rows;
		} elseif(substr_count($sql, "INSERT")) {
			
			$id = mysqli_insert_id($link);
			return ($id == 0) ? false : $id;
		} else {
			$end = mysqli_affected_rows($link);
			return $res;
		}
	}
?>