<?php 
	require('db.php');

	$uid = $_POST['uid'];
	$mobile = $_POST['mobile'];
	$pwd = md5($_POST['pwd']);
	$sql = "UPDATE user SET pwd='{$pwd}',mobile='{$mobile}' WHERE uid={$uid}";
	$res = DB($sql);
	if ($res) {
		echo "修改成功";
		header("Refresh:3,url=home.php");
	} else {
		echo "失败";
		header("Refresh:3,url=modify.php?uid={$uid}");

	}
?>