<?php
	require('db.php');
	$uid = $_GET['uid'];
	echo $uid;
	$sql = "DELETE FROM user WHERE uid={$uid}";
	echo $sql;
	$res = DB($sql);
	if ($res) {
		echo "删除成功";
	} else {
		echo "失败";
	}
	header("Refresh:3,url=home.php")
?>