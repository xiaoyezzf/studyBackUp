<?php
	require('db.php');
	$uid = $_GET['uid'];
	$sql = "SELECT * FROM user WHERE uid={$uid}";
	$res = DB($sql)[0];
	var_dump($res);
	$html = "<div><form action='modify_submit.php' method='POST'><p>用户名:{$res['uname']}</p><p>手机号:<input type='text' name='mobile' value='{$res['mobile']}'></p><p>密　码:<input type='password' name='pwd' value='{$res['pwd']}'></p><p><input type='submit' name='' value='注册'><input type='hidden' name='uid' value='{$res['uid']}'></p></form></div>";
	echo $html;

?>