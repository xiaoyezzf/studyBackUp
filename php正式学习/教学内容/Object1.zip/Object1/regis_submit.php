<?php 
	require('db.php');
	if(!empty($_POST)) {
		$uname = $_POST['uname'];
		$pwd = md5($_POST['pwd']);
		$mobile = $_POST['mobile'];
		
		$sql = "INSERT INTO user(uname,pwd,mobile) VALUES('{$uname}','{$pwd}','{$mobile}')";
		$res = DB($sql);
		if ($res) {
			echo "注册成功";
			header("Refresh:3,url=login.html");
		} else {
			echo "失败";
			header("Refresh:3,url=regis.php");
		}
	}
?>