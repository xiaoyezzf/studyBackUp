<?php 
	require('db.php');
	$sql = "SELECT * FROM user";
	$res = DB($sql);

	$html = "<a href='regis.html'>添加</a><table border='1'><tr><td>ID</td><td>用户名</td><td>手机号</td><td>密码</td><td>操作</td></tr>";
	foreach ($res as $value) {
		$html .="<tr><td>{$value['uid']}</td><td>{$value['uname']}</td><td>{$value['mobile']}</td><td>{$value['pwd']}</td><td><a href='modify.php?uid={$value['uid']}'>修改</a><a href='delete.php?uid={$value['uid']}'>删除</a></td></tr>";
	}
	$html .= "</table>";
	echo $html;
?>